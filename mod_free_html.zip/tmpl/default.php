<?php
/*
*Имя приложения: Free HTML
*Версия:1
*Автор:Boyko Dmitry
*Дата:10.05.2018
*Описание:шаблон.
*/
defined('_JEXEC') or die; 
echo $html;
?>

